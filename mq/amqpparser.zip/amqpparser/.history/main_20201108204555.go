package main

import (
	"bytes"
	"flag"
	"fmt"
	"log"
	"path/filepath"

	"github.com/google/gopacket"
	"github.com/google/gopacket/layers"
	"github.com/google/gopacket/pcap"

	"amqp.d01t.now/amqp"
)

func handleError(err error, msg string) {
	if err != nil {
		log.Fatalf("%s: %s\n", msg, err)
	}
}

var traceLogEnabled bool

func printPacketInfo(packet gopacket.Packet, parser amqp.AppPayloadParser) {
	var (
		client amqp.ClientEP
		server amqp.ServerEP
	)
	setHost := func(ip *layers.IPv4) {
		if isServerHost(ip.SrcIP.String()) {
			server.Host = ip.SrcIP.String()
			client.Host = ip.DstIP.String()
		} else {
			server.Host = ip.DstIP.String()
			client.Host = ip.SrcIP.String()
		}
	}
	setIP := func(tcp *layers.TCP) {
		if isServerPort(tcp.SrcPort.String()) {
			server.Port = tcp.SrcPort.String()
			client.Port = tcp.DstPort.String()
		} else {
			server.Port = tcp.DstPort.String()
			client.Port = tcp.SrcPort.String()
		}

	}
	var traceLog bool
	if packet.ApplicationLayer() != nil {

	}
	fmt.Println("---------", packet.Metadata().Timestamp)
	ethLayer := packet.Layer(layers.LayerTypeEthernet)
	if ethLayer != nil {
		if traceLog {
			fmt.Println("ethernet layer detected")
			fmt.Println()
		}
	}
	ipLayer := packet.Layer(layers.LayerTypeIPv4)
	if ipLayer != nil {
		ip, _ := ipLayer.(*layers.IPv4)
		setHost(ip)
		if traceLog {
			fmt.Println("ipv4 layer detected")
			fmt.Printf("from %s to %s\n", ip.SrcIP, ip.DstIP)
			fmt.Println("protocol:", ip.Protocol)
			fmt.Println()
		}
	}
	tcpLayer := packet.Layer(layers.LayerTypeTCP)
	if tcpLayer != nil {
		tcp, _ := tcpLayer.(*layers.TCP)
		setIP(tcp)
		if traceLog {
			fmt.Println("TCP layer detected")
			fmt.Printf("from port: %d, to port: %d\n", tcp.SrcPort, tcp.DstPort)
			fmt.Println()
		}
	}
	appLayer := packet.ApplicationLayer()
	if appLayer != nil {
		fmt.Println("application layer/Payload found")
		fmt.Printf("server: %v, client: %v\n", server, client)
		r := bytes.NewReader(appLayer.Payload())
		parser.Parse(r, &server, &client)
		fmt.Println()

	}
	if err := packet.ErrorLayer(); err != nil {
		fmt.Println("error decoding some part of packet:", err)
		fmt.Println()
	}
	fmt.Println("================================")
	fmt.Println()
	fmt.Println()
}

func isServerHost(host string) bool {
	return host == "192.168.50.38"
}
func isServerPort(port string) bool {
	return port == "5672"
}

func parsePcap(file string) {
	if file == "" {
		return
	}
	handle, err := pcap.OpenOffline(file)
	handleError(err, "open offline failed")
	packageSource := gopacket.NewPacketSource(handle, handle.LinkType())

	ap := amqp.NewParser()
	for packet := range packageSource.Packets() {
		printPacketInfo(packet, ap)
	}
}

var (
	clientPcap string
	serverPcap string
)

func init() {
	flag.StringVar(&clientPcap, "c", "", "client pcap file")
	flag.StringVar(&serverPcap, "s", "", "server pcap file")
}

func main() {
	flag.Parse()
	fmt.Println(clientPcap, serverPcap)
	if clientPcap != "" {
		clientPcap, err := filepath.Abs(clientPcap)
		if err != nil {
			log.Fatal(err)
		}
		parsePcap(clientPcap)

	}
	if serverPcap != "" {
		serverPcap, err := filepath.Abs(serverPcap)
		if err != nil {
			log.Fatal(err)
		}
		parsePcap(serverPcap)

	}
}

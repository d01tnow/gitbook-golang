package main

import (
	"bytes"
	"flag"
	"fmt"
	"io"
	"log"
	"path/filepath"

	"github.com/google/gopacket"
	"github.com/google/gopacket/layers"
	"github.com/google/gopacket/pcap"

	"amqp.d01t.now/amqp"
)

func handleError(err error, msg string) {
	if err != nil {
		log.Fatalf("%s: %s\n", msg, err)
	}
}

// AppPayloadParser -
type AppPayloadParser interface {
	Parse(io.Reader) error
}

func printPacketInfo(packet gopacket.Packet, parser AppPayloadParser) {
	ethLayer := packet.Layer(layers.LayerTypeEthernet)
	if ethLayer != nil {
		fmt.Println("ethernet layer detected")
		fmt.Println()
	}
	ipLayer := packet.Layer(layers.LayerTypeIPv4)
	if ipLayer != nil {
		fmt.Println("ipv4 layer detected")
		ip, _ := ipLayer.(*layers.IPv4)
		fmt.Printf("from %s to %s\n", ip.SrcIP, ip.DstIP)
		fmt.Println("protocol:", ip.Protocol)
		fmt.Println()
	}
	tcpLayer := packet.Layer(layers.LayerTypeTCP)
	if tcpLayer != nil {
		fmt.Println("TCP layer detected")
		tcp, _ := tcpLayer.(*layers.TCP)
		fmt.Printf("from port: %d, to port: %d\n", tcp.SrcPort, tcp.DstPort)
		fmt.Println()
	}
	appLayer := packet.ApplicationLayer()
	if appLayer != nil {
		fmt.Println("application layer/Payload found")
		r := bytes.NewReader(appLayer.Payload())
		parser.Parse(r)
		fmt.Println()

	}
	if err := packet.ErrorLayer(); err != nil {
		fmt.Println("error decoding some part of packet:", err)
		fmt.Println()
	}
}

func parsePcap(file string) {
	if file == "" {
		return
	}
	handle, err := pcap.OpenOffline(file)
	handleError(err, "open offline failed")
	packageSource := gopacket.NewPacketSource(handle, handle.LinkType())
	ap := &amqp.Connection{}
	for packet := range packageSource.Packets() {
		printPacketInfo(packet, ap)
	}
}

func main() {
	flag.Parse()
	if flag.NArg() < 1 {
		fmt.Println("Usage: amqpparser path-to-client.pcap path-to-server.pcap")
		return
	}

	clientPcap, err := filepath.Abs(flag.Arg(0))
	if err != nil {
		log.Fatal(err)
	}

	parsePcap(clientPcap)
	if flag.NArg() > 1 {
		serverPcap, err := filepath.Abs(flag.Arg(1))
		if err != nil {
			log.Fatal(err)
		}
		parsePcap(serverPcap)

	}

}

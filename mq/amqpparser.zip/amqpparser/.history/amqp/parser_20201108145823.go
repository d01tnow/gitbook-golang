package amqp

import (
	"bufio"
	"io"
	"log"
)

// Endpoint -
type Endpoint struct {
	Host string
	Port int
}

type ServerEP = Endpoint
type ClientEP = Endpoint

// AppPayloadParser -
type AppPayloadParser interface {
	Parse(io.Reader, ServerEP, ClientEP) error
}

// Parser -
type Parser struct {
	connections map[uint]*Connection
}

// Parse -
func (p *Parser) Parse(r io.Reader, serverEP ServerEP, clientEP ClientEP) error {
	buf := bufio.NewReader(r)
	frames := &reader{buf}
	for {
		frame, err := frames.ReadFrame()
		if err != nil {
			log.Println("read frame failed, err:", err)
			if err == io.EOF {
				return err
			}
		} else {
			p.demux(frame)
		}
	}
}

func (p *Parser) demux(f frame) {
	if f.channel() == 0 {
	} else {
	}
}

package amqp

import (
	"bufio"
	"io"
	"log"
)

// Endpoint -
type Endpoint struct {
	Host string
	Port string
}

type ServerEP = Endpoint
type ClientEP = Endpoint

// AppPayloadParser -
type AppPayloadParser interface {
	Parse(io.Reader, *ServerEP, *ClientEP) error
}

// Parser -
type Parser struct {
	connections map[string]*Connection
}

func NewParser() *Parser {
	return &Parser{
		connections: make(map[string]*Connection),
	}
}
func (p *Parser) getConnection(ep *ClientEP) *Connection {
	if conn, ok := p.connections[ep.Port]; ok {
		return conn
	}
	conn := NewConnection(ep.Port)
	p.connections[ep.Port] = conn
	return conn
}

// Parse -
func (p *Parser) Parse(r io.Reader, serverEP *ServerEP, clientEP *ClientEP) error {
	conn := p.getConnection(clientEP)
	buf := bufio.NewReader(r)
	frames := &reader{buf}
	for {
		frame, err := frames.ReadFrame()
		if err != nil {
			log.Println("read frame failed, err:", err)
			if err == io.EOF {
				return err
			}
		} else {
			conn.demux(frame)
		}
	}
}

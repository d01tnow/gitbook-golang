package amqp

import "io"

// Parser -
type Parser struct {
}

// Parse -
func (ap *Parser) Parse(r io.Reader) error {
	return nil
}

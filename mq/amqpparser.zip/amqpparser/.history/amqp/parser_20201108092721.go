package amqp

import (
	"bufio"
	"io"
	"log"
)

// Parser -
type Parser struct {
}

func (p *Parser) demux(f frame) {

}

// Parse -
func (p *Parser) Parse(r io.Reader) error {
	buf := bufio.NewReader(r)
	frames := &reader{buf}
	for {
		frame, err := frames.ReadFrame()
		if err != nil {
			log.Println("read frame failed, err:", err)
			return err
		}
		p.demux(frame)

	}

}

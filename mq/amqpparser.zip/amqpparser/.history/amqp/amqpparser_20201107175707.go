package amqp

import "io"

// AmqpParser -
type Parser struct {
}

// Parse -
func (ap *Parser) Parse(r io.Reader) error {
	return nil
}

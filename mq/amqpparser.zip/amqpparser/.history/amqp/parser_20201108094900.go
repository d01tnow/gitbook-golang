package amqp

import (
	"bufio"
	"fmt"
	"io"
	"log"
	"sync"
)

// Parser -
type Parser struct {
	rpc      chan message
	m        sync.Mutex
	channels map[uint16]*Channel
}

func (p *Parser) demux(f frame) {

}

func (p *Parser) dispatch0(f frame) {
	switch mf := f.(type) {
	case *methodFrame:
		switch m := mf.Method.(type) {
		case *connectionClose:
			fmt.Println("connection close")
		case *connectionBlocked:
			fmt.Println("connection blocked")
		case *connectionUnblocked:
			fmt.Println("connection unblocked")
		default:
			p.rpc <- m
		}
	case *heartbeatFrame:
		// kthx - all reads reset our deadline.  so we can drop this
	default:
		// lolwat - channel0 only responds to methods and heartbeats
		// c.closeWith(ErrUnexpectedFrame)
		fmt.Println("error: unexpected frame")
	}
}

func (p *Parser) dispatchN(f frame) {
	p.m.Lock()
	channel := p.channels[f.channel()]
	p.m.Unlock()

	if channel != nil {
		channel.recv(channel, f)
	} else {
		p.dispatchClosed(f)
	}
}
func (p *Parser) dispatchClosed(f frame) {
	channel := &Channel{}
	p.m.Lock()
	p.channels[f.channel()] = channel
	p.m.Unlock()
	channel.recv(channel, f)
}

// Parse -
func (p *Parser) Parse(r io.Reader) error {
	buf := bufio.NewReader(r)
	frames := &reader{buf}
	for {
		frame, err := frames.ReadFrame()
		if err != nil {
			log.Println("read frame failed, err:", err)
			return err
		}
		p.demux(frame)

	}

}

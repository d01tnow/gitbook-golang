package amqp

import "io"

// AmqpParser -
type AmqpParser struct {
}

// Parse -
func (ap *AmqpParser) Parse(r io.Reader) error {
	return nil
}

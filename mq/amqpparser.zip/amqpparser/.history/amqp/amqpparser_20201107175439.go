package amqp

import "io"

type Amqpparser struct {
}

// Parse -
func (ap *Amqpparser) Parse(r io.Reader) error {

	return nil
}

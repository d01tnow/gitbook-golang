package amqp

import "io"

type amqpparser struct {
}

func (ap *amqpparser) Parse(r io.Reader) error {

}

package amqp

import (
	"bufio"
	"fmt"
	"io"
	"log"
	"sync"
)

// Parser -
type Parser struct {
	rpc chan message
	m   sync.Mutex
}

func (p *Parser) demux(f frame) {

}

func (c *Parser) dispatch0(f frame) {
	switch mf := f.(type) {
	case *methodFrame:
		switch m := mf.Method.(type) {
		case *connectionClose:
			fmt.Println("connection close")
		case *connectionBlocked:
			fmt.Println("connection blocked")
		case *connectionUnblocked:
			fmt.Println("connection unblocked")
		default:
			c.rpc <- m
		}
	case *heartbeatFrame:
		// kthx - all reads reset our deadline.  so we can drop this
	default:
		// lolwat - channel0 only responds to methods and heartbeats
		// c.closeWith(ErrUnexpectedFrame)
		fmt.Println("error: unexpected frame")
	}
}

func (c *Parser) dispatchN(f frame) {
	c.m.Lock()
	channel := c.channels[f.channel()]
	c.m.Unlock()

	if channel != nil {
		channel.recv(channel, f)
	} else {
		c.dispatchClosed(f)
	}
}

// Parse -
func (p *Parser) Parse(r io.Reader) error {
	buf := bufio.NewReader(r)
	frames := &reader{buf}
	for {
		frame, err := frames.ReadFrame()
		if err != nil {
			log.Println("read frame failed, err:", err)
			return err
		}
		p.demux(frame)

	}

}

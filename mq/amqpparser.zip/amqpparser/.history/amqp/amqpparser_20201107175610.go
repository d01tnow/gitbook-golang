package amqp

import "io"

// AmqpParser
type Amqpparser struct {
}

// Parse -
func (ap *Amqpparser) Parse(r io.Reader) error {
	return nil
}

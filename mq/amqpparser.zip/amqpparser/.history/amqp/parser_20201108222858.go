package amqp

import (
	"bufio"
	"fmt"
	"io"
	"log"
	"time"
)

// Endpoint -
type Endpoint struct {
	Host string
	Port string
}

type ServerEP = Endpoint
type ClientEP = Endpoint

type ConnectionInfo struct {
	ServerEP
	ClientEP
}

type WrappedMessage struct {
	ConnectionInfo
	ChannelID   uint16
	ConsumerTag string
	Body        []byte
}

// AppPayloadParser -
type AppPayloadParser interface {
	Parse(io.Reader, *ServerEP, *ClientEP) error
}

// Parser -
type Parser struct {
	connections map[string]*Connection
	chMsg       chan *WrappedMessage
}

func NewParser() *Parser {
	return &Parser{
		connections: make(map[string]*Connection),
		chMsg:       make(chan *WrappedMessage, 1),
	}
}
func (p *Parser) getConnection(sep *ServerEP, cep *ClientEP) *Connection {
	if conn, ok := p.connections[cep.Port]; ok {
		return conn
	}
	conn := NewConnection(sep, cep, p.chMsg)
	p.connections[cep.Port] = conn
	return conn
}

func (p *Parser) handleMsg() {
	for {
		select {
		case msg := <-p.chMsg:
			var mymsg MyMessage
			err := mymsg.Unmarshal(msg.Body)
			if err != nil {
				fmt.Println("unable to unmarsh, err:", err)
				continue
			}
			fmt.Printf("serverIP: %s, serverPort: %s, clientIP: %s, clientPort: %s, message.id: %d, message.start: %s\n",
				msg.ServerEP.Host,
				msg.ServerEP.Port,
				msg.ClientEP.Host,
				msg.ClientEP.Port,
				mymsg.id,
				mymsg.start.Format(time.RFC3339Nano),
			)
		}
	}
}

// Parse -
func (p *Parser) Parse(r io.Reader, serverEP *ServerEP, clientEP *ClientEP) error {
	go p.handleMsg()
	conn := p.getConnection(serverEP, clientEP)
	buf := bufio.NewReader(r)
	frames := &reader{buf}
	for {
		frame, err := frames.ReadFrame()
		if err != nil {
			log.Println("read frame failed, err:", err)
			if err == io.EOF {
				return err
			}
		} else {
			conn.demux(frame)
		}
	}
}

package amqp

import (
	"bufio"
	"io"
	"log"
)

type Parser struct {
}

func (p *Parser) Parse(io.Reader) error {
	buf := bufio.NewReader(r)
	frames := &reader{buf}
	for {
		frame, err := frames.ReadFrame()
		if err != nil {
			log.Println("read frame failed, err:", err)
			if err == io.EOF {
				return err
			}
		} else {
			c.demux(frame)
		}
	}
}

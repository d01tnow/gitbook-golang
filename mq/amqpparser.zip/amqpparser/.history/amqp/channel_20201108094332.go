package amqp

type Channel struct {
	recv func(*Channel, frame) error
}

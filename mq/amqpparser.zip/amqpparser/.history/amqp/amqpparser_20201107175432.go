package amqp

import "io"

type Amqpparser struct {
}

func (ap *Amqpparser) Parse(r io.Reader) error {

	return nil
}

package amqp

import (
	"bufio"
	"io"
)

// Parser -
type Parser struct {
}

// Parse -
func (ap *Parser) Parse(r io.Reader) error {
	buf := bufio.NewReader(r)
	frames := &reader{buf}
	for {
		frame, err := frames.ReadFrame()
	}

	return nil
}

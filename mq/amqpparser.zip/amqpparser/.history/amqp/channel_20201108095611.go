package amqp

// Channel -
type Channel struct {
	id         uint16
	connection *Connection
	body       []byte
	message    messageWithContent
	rpc        chan message
	errors     chan *Error
	recv       func(*Channel, frame) error
}

func newChannel(c *Connection, id uint16) *Channel {
	return &Channel{
		connection: c,
		id:         id,
		rpc:        make(chan message),
		// consumers:  makeConsumers(),
		// confirms:   newConfirms(),
		recv:   (*Channel).recvMethod,
		errors: make(chan *Error, 1),
	}
}
func (ch *Channel) transition(f func(*Channel, frame) error) error {
	ch.recv = f
	return nil
}

func (ch *Channel) recvMethod(f frame) error {
	switch frame := f.(type) {
	case *methodFrame:
		if msg, ok := frame.Method.(messageWithContent); ok {
			ch.body = make([]byte, 0)
			ch.message = msg
			return ch.transition((*Channel).recvHeader)
		}

		ch.dispatch(frame.Method) // termination state
		return ch.transition((*Channel).recvMethod)

	case *headerFrame:
		// drop
		return ch.transition((*Channel).recvMethod)

	case *bodyFrame:
		// drop
		return ch.transition((*Channel).recvMethod)
	}

	panic("unexpected frame type")
}

func (ch *Channel) recvHeader(f frame) error {
	switch frame := f.(type) {
	case *methodFrame:
		// interrupt content and handle method
		return ch.recvMethod(f)

	case *headerFrame:
		// start collecting if we expect body frames
		ch.header = frame

		if frame.Size == 0 {
			ch.message.setContent(ch.header.Properties, ch.body)
			ch.dispatch(ch.message) // termination state
			return ch.transition((*Channel).recvMethod)
		}
		return ch.transition((*Channel).recvContent)

	case *bodyFrame:
		// drop and reset
		return ch.transition((*Channel).recvMethod)
	}

	panic("unexpected frame type")
}

// state after method + header and before the length
// defined by the header has been reached
func (ch *Channel) recvContent(f frame) error {
	switch frame := f.(type) {
	case *methodFrame:
		// interrupt content and handle method
		return ch.recvMethod(f)

	case *headerFrame:
		// drop and reset
		return ch.transition((*Channel).recvMethod)

	case *bodyFrame:
		if cap(ch.body) == 0 {
			ch.body = make([]byte, 0, ch.header.Size)
		}
		ch.body = append(ch.body, frame.Body...)

		if uint64(len(ch.body)) >= ch.header.Size {
			ch.message.setContent(ch.header.Properties, ch.body)
			ch.dispatch(ch.message) // termination state
			return ch.transition((*Channel).recvMethod)
		}

		return ch.transition((*Channel).recvContent)
	}

	panic("unexpected frame type")
}

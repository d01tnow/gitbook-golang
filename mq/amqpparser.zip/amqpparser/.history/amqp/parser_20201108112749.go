package amqp

import "io"

type Parser struct {
}

func (p *Parser) Parse(io.Reader) error {

}

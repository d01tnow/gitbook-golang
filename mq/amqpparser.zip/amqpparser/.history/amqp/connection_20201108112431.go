package amqp

import (
	"bufio"
	"fmt"
	"io"
	"log"
	"sync"
)

// Connection -
type Connection struct {
	rpc      chan message
	m        sync.Mutex
	channels map[uint16]*Channel
}

func NewConnection() *Connection {
	return &Connection{
		rpc:      make(chan message),
		channels: make(map[uint16]*Channel),
	}
}

func (c *Connection) demux(f frame) {
	if f.channel() == 0 {
		c.dispatch0(f)
	} else {
		c.dispatchN(f)
	}
}

func (c *Connection) dispatch0(f frame) {
	switch mf := f.(type) {
	case *methodFrame:
		switch m := mf.Method.(type) {
		case *connectionClose:
			fmt.Println("connection close")
		case *connectionBlocked:
			fmt.Println("connection blocked")
		case *connectionUnblocked:
			fmt.Println("connection unblocked")
		default:
			fmt.Println("connection type:", m)
			// c.rpc <- m
		}
	case *heartbeatFrame:
		// kthx - all reads reset our deadline.  so we can drop this
	default:
		// lolwat - channel0 only responds to methods and heartbeats
		// c.closeWith(ErrUnexpectedFrame)
		fmt.Println("error: unexpected frame")
	}
}

func (c *Connection) dispatchN(f frame) {
	c.m.Lock()
	channel := c.channels[f.channel()]
	c.m.Unlock()

	if channel != nil {
		channel.recv(channel, f)
	} else {
		c.dispatchClosed(f)
	}
}

var gid uint16

func genID() uint16 {
	gid++
	return gid
}

func (c *Connection) dispatchClosed(f frame) {
	channel := newChannel(c, f.channel())
	fmt.Println("dispatchClosed, channel id: ", f.channel())
	c.m.Lock()
	c.channels[f.channel()] = channel
	c.m.Unlock()
	channel.recv(channel, f)
}

// Parse -
func (c *Connection) Parse(r io.Reader) error {
	buf := bufio.NewReader(r)
	frames := &reader{buf}
	for {
		frame, err := frames.ReadFrame()
		if err != nil {
			log.Println("read frame failed, err:", err)
			if err == io.EOF {
				return err
			}
		} else {
			c.demux(frame)
		}
	}

}

func (c *Connection) closeChannel(ch *Channel, err error) {

}

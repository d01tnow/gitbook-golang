package amqp

import (
	"bufio"
	"io"
	"log"
)

// Endpoint -
type Endpoint struct {
	Host string
	Port string
}

type ServerEP = Endpoint
type ClientEP = Endpoint

type ConnectionInfo struct {
	ServerEP
	ClientEP
}

type WrappedMessage struct {
	ConnectionInfo
	ChannelID   uint16
	ConsumerTag string
	Body        []byte
}

// AppPayloadParser -
type AppPayloadParser interface {
	Parse(io.Reader, *ServerEP, *ClientEP) error
}

// Parser -
type Parser struct {
	connections map[string]*Connection
	chMsg       chan *WrappedMessage
}

func NewParser() *Parser {
	return &Parser{
		connections: make(map[string]*Connection),
	}
}
func (p *Parser) getConnection(sep *ServerEP, cep *ClientEP) *Connection {
	if conn, ok := p.connections[cep.Port]; ok {
		return conn
	}
	conn := NewConnection(sep, cep, p.chMsg)
	p.connections[cep.Port] = conn
	return conn
}

// Parse -
func (p *Parser) Parse(r io.Reader, serverEP *ServerEP, clientEP *ClientEP) error {
	conn := p.getConnection(serverEP, clientEP)
	buf := bufio.NewReader(r)
	frames := &reader{buf}
	for {
		frame, err := frames.ReadFrame()
		if err != nil {
			log.Println("read frame failed, err:", err)
			if err == io.EOF {
				return err
			}
		} else {
			conn.demux(frame)
		}
	}
}

package main

import (
	"flag"
	"fmt"
	"log"

	"github.com/google/gopacket"
	"github.com/google/gopacket/layer"
	"github.com/google/gopacket/pcap"
)

func handleError(err error, msg string) {
	if err != nil {
		log.Fatalf("%s: %s\n", msg, err)
	}
}
func printPacketInfo(packet gopacket.Packet) {
	ethLayer := packet.Layer(layer.LayerTypeEthernet)
	if ethLayer != nil {
		fmt.Println("ethernet layer detected")
	}
}

func parsePcap(file string) {
	if file == "" {
		return
	}
	handle, err := pcap.OpenOffline(file)
	handleError(err, "open offline failed")
	packageSource := gopacket.NewPacketSource(handle, handle.LinkType())
	for packet := range packageSource.Packets() {
		printPacketInfo(packet)
	}
}

func main() {
	flag.Parse()

	var clientPcap string
	var serverPcap string
	parsePcap(clientPcap)
	parsePcap(serverPcap)

}
